export class User{

    User_Id!:number;
    Username!:string;
    Email!:string
    First_Name!:string;
    Last_Name!:string;
    Contact_Number!:number;
    ROLE!:string;
    isActive!:boolean;
    DOB!:string;
    Created_On!:string;
    Password!:string
    
    }