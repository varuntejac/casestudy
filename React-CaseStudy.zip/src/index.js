import React from 'react';
import ReactDOM from 'react-dom';
import { Link, Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import Addtask from './Components/Addtask';
import GetAllTasks from './Components/GetAllTasks';
import Gettaskbyid from './Components/Gettaskbyid';
import AssignTask from './Components/AssignTask';
import DeleteTask from './Components/DeleteTask';
import UpdateBookmark from './Components/UpdateBookmark';
import UpdateNotes from './Components/UpdateNotes';
import UpdatePriority from './Components/UpdatePriority';
import SearchStatus from './Components/SearchStatus';

function App() {
  return (
    <div>
       <h2  style={{"color":"Blue","textAlign":"center","textShadow":"3px  4px 5px  red"}}>TASK TRACKING SYSTEM</h2>
      <ul style={{'listStyleType':'circle'}}>
        <li><Link to="/search">Tracking By Status</Link></li>
        <li><Link to="/addtask">AddTask</Link></li>
        <li><Link to="/getalltask">GetAllTasks</Link></li>
        <li><Link to="/getbyid">GetById</Link></li>
        <li><Link to="/assigntask">AssignTask</Link></li>
        <li><Link to="/deletetask">DeleteTask</Link></li>

        <li><Link to="/upbookmark">UpdateBookmark</Link></li>
        <li><Link to="/upnotes">UpdateNotes</Link></li>
        <li><Link to="/uppriority">UpdatePriority</Link></li>
        
 
      </ul>
      <Routes>
      
        <Route path="/addtask" element={<Addtask/>}></Route>
        <Route path="/getalltask" element={<GetAllTasks/>}></Route>
        <Route path="/getbyid" element={<Gettaskbyid/>}></Route>
        <Route path="/assigntask" element={<AssignTask/>}></Route>
        <Route path="/deletetask" element={<DeleteTask/>}></Route>
        
        <Route path="/upbookmark" element={<UpdateBookmark/>}></Route>
        <Route path="/upnotes" element={<UpdateNotes/>}></Route>
        <Route path="/uppriority" element={<UpdatePriority/>}></Route>
        <Route path="/search" element={<SearchStatus/>}></Route>
      </Routes>

    </div>
  )
}



ReactDOM.render(

  <Router>
    <App></App>
  </Router>,

  document.getElementById('root')
);
