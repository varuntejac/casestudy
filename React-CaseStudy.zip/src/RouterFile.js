
import React from "react";
import reactDom from "react-dom";
import { Route,Link,BrowserRouter as Router, Routes } from "react-router-dom";
import Addtask from './Components/Addtask'
import Gettaskbyid from './Components/Gettaskbyid'
import App from "./App";
import GetAllTasks from "./Components/GetAllTasks";
import Updatetask from "./Components/UpdatePriority";
import UpdatePriority from "./Components/UpdatePriority";
const routing=(
    <Router>
        <div>
            <ul>
                <li>
                    <Link to="/">Home</Link>
                </li>
                <li>
                    <Link to="/add">Add Task</Link>
                </li>
                <li>
                    <Link to="/getbyid">Get Task byId</Link>
                </li>
                <li>
                    <Link to="/getalltask">GetAllTasks</Link>
                </li>
                <li>
                    <Link to="/updatepriority">updatepriority</Link>
                </li>
            </ul>
            <Routes>
                <Route path="/" element={<App/>}/>
                <Route path="/add" element={<Addtask/>}/>
                <Route path="/getid" element={<Gettaskbyid/>}/>
                <Route path="/getalltask" element={<GetAllTasks/>}/>
                <Route path="/updatepriority" element={<UpdatePriority/>}/>
            </Routes>
        </div>
    </Router>
)
export default routing;