import React, { Component } from "react";
import axios from "axios";

class SearchStatus extends Component {
    constructor() {
        super()
        this.state = {
            status:'',
            tasks:[]
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) =>  {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/trackstatus/"+this.state.status,this.state)
            .then(response => this.setState({ tasks: response.data }))
    }
    
    render() {
        const {status} = this.state
        return (
          
            <div style={{"backgroundColor":"#eab4ed","color":"black","textAlign":"center","opacity":"0.8","margin":"10px 400px 10px"}}>
                <h3 style={{"color":"red","backgroundColor":"aqua","textAlign":"center"}}>SearchbyStatus</h3>
                  <form  onSubmit={this.submitHandler}>
                
                <div>
                status:
                        <select  name="status" value={status} onChange={this.changeHandler}  placeholder="status" required >
                        <option value ="select">select</option>
                        <option value="Close">Close</option>
                        <option value="InProgress">InProgress</option>
                        <option value="Cancelled">Cancelled</option>
                        <option value="OnHold">OnHold</option>
                        </select>

                    </div>
                 <button className='button' type="submit">Submit</button>

            </form>
            {this.state.tasks.map(task => (<h3>
                    Task_ID: {task.task_Id} <br />
                    Owner_ID: {task.owner_Id} <br />
                    Creator_ID: {task.creator_Id} <br />
                    Name: {task.name} <br />
                    Description: {task.description} <br />
                    Status: {task.status} <br />
                    Priority: {task.priority} <br />
                    Notes: {task.notes} <br />
                    IsBookmarked: {task.isBookmarked.toString()} <br />
                    Created_On: {task.created_On} <br />
                    Status_Changed_On: {task.statusChanged_On} <br />
                 
                </h3>))}
            </div>
            





        )
    }

}
export default SearchStatus;