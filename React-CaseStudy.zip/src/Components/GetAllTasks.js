import React, { Component } from 'react';
import axios from 'axios';



class GetAllTasks extends Component {
    constructor() {
        super()
        this.state = {
            tasks: []
        }
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick() {
        axios.get('http://localhost:8080/listtask')
            .then(response => this.setState({ tasks: response.data }))
    }
   
    render() {
        return (
            <div>
                <h2 style={{"color":"red","textAlign":"center","opacity":"0.8","margin":"10px 400px 10px",'textShadow':'3px  4px 5px  red'}}>GetAllTasks</h2>
            <div style={{ "backgroundColor": "#18b8b2", "color": "black", "textAlign": "center","opacity":"0.8","margin":"10px 400px 10px" }}>
                
                <button className='button' onClick={this.handleClick}>Click Here for TaskList</button>
                {this.state.tasks.map(task => (<h3>
                    Task_ID: {task.task_Id} <br />
                    Owner_ID: {task.owner_Id} <br />
                    Creator_ID: {task.creator_Id} <br />
                    Name: {task.name} <br />
                    Description: {task.description} <br />
                    Status: {task.status} <br />
                    Priority: {task.priority} <br />
                    Notes: {task.notes} <br />
                    IsBookmarked: {task.isBookmarked.toString()} <br />
                    Created_On: {task.created_On} <br />
                    Status_Changed_On: {task.statusChanged_On} <br />
                 
                </h3>))}
            </div>
            </div>
        )
    }
}
export default GetAllTasks;