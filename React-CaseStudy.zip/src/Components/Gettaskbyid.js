import React, { Component } from "react";
import axios from "axios";

class Gettaskbyid extends Component {
    constructor() {
        super()
        this.state = {
            Taskname: '', Taskid: '', Priority: '', Status: '', OwnerId: '', isBookmarked: '',taskID:'',Creator_Id:'',Description:'',
            Notes:'',Created_On:''
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) =>  {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/gettask/"+this.state.taskID,this.state)
            .then(response => this.setState({
                Taskname: response.data.name, Taskid: response.data.task_Id,
                Priority: response.data.priority, Status: response.data.status, OwnerId: response.data.owner_Id, isBookmarked: response.data.isBookmarked,
                Creator_Id: response.data.creator_Id, Description: response.data.description, Notes: response.data.notes,
                Created_On: response.data.created_On
            }))
    }
    
    render() {
        const {taskID} = this.state
        return (
          
            <div style={{"backgroundColor":"#eab4ed","color":"black","textAlign":"center","opacity":"0.8","margin":"10px 400px 10px"}}>
                <h3 style={{"color":"red","backgroundColor":"aqua","textAlign":"center"}}>GetTaskByTaskid</h3>
                  <form  onSubmit={this.submitHandler}>
                <div>
                taskID:
                    <input type="number" name="taskID" value={taskID} onChange={this.changeHandler} placeholder="taskID" required/>
                </div>
                 <button className='button' type="submit">Submit</button>

            </form>
                
                <table style={{"backgroundColor":"silver"}}>
                    <thead>
                        <tr>
                            <th>TaskName</th>
                            <th>Task_Id</th>
                            <th>priority</th>
                            <th>status</th>
                            <th>OwnerId</th>
                            <th>isBookmarked</th>
                            <th>Creator_Id</th>
                            <th>Description</th>
                            <th>Notes</th>
                            <th>Created_On</th>
                            </tr>
                    </thead>
                    <tbody>
                        <tr if="tasdata">
                            <td>{this.state.Taskname}</td>
                            <td>{this.state.Taskid}</td>
                            <td>{this.state.Priority}</td>
                            <td>{this.state.Status}</td>
                            <td>{this.state.OwnerId}</td>
                            <td>{this.state.isBookmarked.toString()}</td>
                            <td>{this.state.Creator_Id}</td>
                            <td>{this.state.Description}</td>
                            <td>{this.state.Notes}</td>
                            <td>{this.state.Created_On}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            





        )
    }

}
export default Gettaskbyid;