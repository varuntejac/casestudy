import axios from "axios";
import React, { Component } from "react";

class AssignTask extends Component {
    constructor(props){
        super(props)
        this.state = {
            task_Id:'',
            owner_Id:'',
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) => {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/assigntaskuser/"+this.state.task_Id+"/"+this.state.owner_Id,this.state)
        .then(response => {
            console.log(response)
        })
        .catch(error => {
            console.log(error)
        })
    }
    render(){
        const {task_Id,owner_Id} = this.state
        return (
            <div style={{"backgroundColor":"#f5a6aa","color":"black","textAlign":"center","opacity":"0.8","margin":"10px 400px 10px"}}>
                <h3 style={{"color":"red","backgroundColor":"aquamarine","textAlign":"center"}}>AssignTask</h3>
            <form  onSubmit={this.submitHandler}>
                <div>
                    task_Id:
                    <input type="number" name="task_Id" value={task_Id} onChange={this.changeHandler} placeholder="task_Id" required/>
                </div>
                        
                <div>
                owner_Id:
                    <input type="number" name="owner_Id" value={owner_Id} onChange={this.changeHandler} placeholder="owner_Id" required/>
                </div>
                 <button type="submit">Submit</button>

            </form>
        </div>
            
        )
    }
}

export default AssignTask;