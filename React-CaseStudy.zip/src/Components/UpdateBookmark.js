import axios from "axios";
import React, { Component } from "react";

class UpdateBookmark extends Component {
    constructor(props){
        super(props)
        this.state = {
            task_Id:'',
            isBookmarked:'',
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submitHandler=this.submitHandler.bind(this);
    }
    changeHandler = (event) => {
        this.setState({[event.target.name]:event.target.value})
    }
    submitHandler = (event) => {
        event.preventDefault()
        console.log(this.state)
        axios.get("http://localhost:8080/updateisbookmarked/"+this.state.task_Id+"/"+this.state.isBookmarked,this.state)
        .then(response => {
            console.log(response)
        })
        .catch(error => {
            console.log(error)
        })
    }
    render(){
        const {task_Id,isBookmarked} = this.state
        return (
            <div style={{"backgroundColor":"#75d1f0","color":"black","textAlign":"center","opacity":"0.8","margin":"10px 400px 10px"}}>
                <h3 style={{"color":"red","backgroundColor":"aquamarine","textAlign":"center"}}>UpdateBookmark</h3>
            <form  onSubmit={this.submitHandler}>
                <div>
                    task_Id:
                    <input type="number" name="task_Id" value={task_Id} onChange={this.changeHandler} placeholder="task_Id" required/>
                </div>
                        
                <div>
                isBookmarked :
                        <select  name="isBookmarked" value={isBookmarked} onChange={this.changeHandler} >
                                <option value="select">select</option>
                                <option value="true">true</option>
                                <option value="false">false</option>
                            
                        </select>
                </div>
                 <button type="submit">Submit</button>

            </form>
        </div>
            
        )
    }
}

export default UpdateBookmark;